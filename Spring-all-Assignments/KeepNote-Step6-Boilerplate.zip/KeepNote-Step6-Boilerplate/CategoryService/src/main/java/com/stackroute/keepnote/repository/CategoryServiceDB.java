package com.stackroute.keepnote.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.model.Category;

@Repository
public class CategoryServiceDB {

	
	@Autowired
	private	CategoryRepository categoryRepository;


	public void setUserRepository(CategoryRepository categoryRepository) {
		this.categoryRepository = categoryRepository;
	}


	public Category saveuser(Category category) {
		return categoryRepository.insert(category);
	}
	public Category findById(String categoryId) {
		return categoryRepository.findById(categoryId).get();
	}
}
