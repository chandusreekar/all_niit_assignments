package com.stackroute.keepnote.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.model.Reminder;

@Repository
public class ReminderServiceDB {

	@Autowired
	private	ReminderRepository reminderRepository;


	public void setUserRepository(ReminderRepository reminderRepository) {
		this.reminderRepository = reminderRepository;
	}


	public Reminder saveuser(Reminder reminder) {
		return reminderRepository.insert(reminder);
	}
	public Reminder findById(String reminderId) {
		return reminderRepository.findById(reminderId).get();
	}
	

}
