package com.stackroute.keepnote.model;

import java.util.Date;
import java.util.List;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Document
public class Note {
	
	/*
	 * This class should have eight fields
	 * (noteId,noteTitle,noteContent,noteStatus,createdAt,
	 * category,reminder,createdBy). This class should also contain the
	 * getters and setters for the fields along with the no-arg , parameterized
	 * constructor and toString method. The value of createdAt should not be
	 * accepted from the user but should be always initialized with the system date.
	 * 
	 */
	@Id
	private int noteId;
	
	private String noteTitle;
	
	private String noteContent;
	
	private String noteStatus;
	
	private String noteCreatedBy;
	
	private Date noteCreationDate;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "categoryId")
	@Fetch(FetchMode.SELECT)
	@Cascade(CascadeType.ALL)
	private Category category;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "reminderId")
	@Fetch(FetchMode.SELECT)
	@Cascade(CascadeType.ALL)
	private List<Reminder> reminders;
	
	@OneToMany
	@JoinColumn (name = "userId")
	@Fetch(FetchMode.SELECT)
	@JsonIgnore
	private List<NoteUser> noteUser;
	

	public Note() {
		super();
	}


	public Note(int noteId, String noteTitle, String noteContent, String noteStatus, String noteCreatedBy,
			Date noteCreationDate, Category category, List<Reminder> reminders, List<NoteUser> noteUser) {
		super();
		this.noteId = noteId;
		this.noteTitle = noteTitle;
		this.noteContent = noteContent;
		this.noteStatus = noteStatus;
		this.noteCreatedBy = noteCreatedBy;
		this.noteCreationDate = noteCreationDate;
		this.category = category;
		this.reminders = reminders;
		this.noteUser = noteUser;
	}


	public int getNoteId() {
		return noteId;
	}


	public void setNoteId(int noteId) {
		this.noteId = noteId;
	}


	public String getNoteTitle() {
		return noteTitle;
	}


	public void setNoteTitle(String noteTitle) {
		this.noteTitle = noteTitle;
	}


	public String getNoteContent() {
		return noteContent;
	}


	public void setNoteContent(String noteContent) {
		this.noteContent = noteContent;
	}


	public String getNoteStatus() {
		return noteStatus;
	}


	public void setNoteStatus(String noteStatus) {
		this.noteStatus = noteStatus;
	}


	public String getNoteCreatedBy() {
		return noteCreatedBy;
	}


	public void setNoteCreatedBy(String noteCreatedBy) {
		this.noteCreatedBy = noteCreatedBy;
	}


	public Date getNoteCreationDate() {
		return noteCreationDate;
	}


	public void setNoteCreationDate(Date noteCreationDate) {
		this.noteCreationDate = noteCreationDate;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	public List<Reminder> getReminders() {
		return reminders;
	}


	public void setReminders(List<Reminder> reminders) {
		this.reminders = reminders;
	}


	public List<NoteUser> getNoteUser() {
		return noteUser;
	}


	public void setNoteUser(List<NoteUser> noteUser) {
		this.noteUser = noteUser;
	}


	@Override
	public String toString() {
		return "Note [noteId=" + noteId + ", noteTitle=" + noteTitle + ", noteContent=" + noteContent + ", noteStatus="
				+ noteStatus + ", noteCreatedBy=" + noteCreatedBy + ", noteCreationDate=" + noteCreationDate
				+ ", category=" + category + ", reminders=" + reminders + ", noteUser=" + noteUser + "]";
	}



		   }
