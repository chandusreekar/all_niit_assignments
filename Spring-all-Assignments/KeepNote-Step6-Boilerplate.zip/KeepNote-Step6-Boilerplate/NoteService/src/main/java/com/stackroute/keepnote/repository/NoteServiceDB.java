package com.stackroute.keepnote.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.model.Category;
import com.stackroute.keepnote.model.Note;
import com.stackroute.keepnote.model.NoteUser;

@Repository
public class NoteServiceDB {

	
	
	@Autowired
	private	NoteRepository noteRepository;

	
	public void setNoteRepository(NoteRepository noteRepository) {
		this.noteRepository = noteRepository;
	}

	public List saveNote(List note) {
		System.out.println("Inside NoteServiceDB");
		return noteRepository.saveAll(note);
	}
	
	public List<Note> findById(int noteId) {
		
		
		return noteRepository.findById(String.valueOf(noteId)).get().getNotes();
	}

}
