package com.stackroute.keepnote.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.model.User;

@Repository
public class UserServiceDB {

	
@Autowired
private UserRepository userRepository;


public void setUserRepository(UserRepository userRepository) {
	this.userRepository = userRepository;
}


public User saveuser(User user) {
	return userRepository.insert(user);
}


		
}
