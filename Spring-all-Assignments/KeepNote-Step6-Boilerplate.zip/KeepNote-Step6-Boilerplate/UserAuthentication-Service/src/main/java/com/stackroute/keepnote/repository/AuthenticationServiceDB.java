package com.stackroute.keepnote.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.model.User;

@Repository
public class AuthenticationServiceDB {

	@Autowired
	private UserAutheticationRepository userAutheticationRepository;

	public void setUserAutheticationRepository(UserAutheticationRepository userAutheticationRepository) {
		this.userAutheticationRepository = userAutheticationRepository;
	}

	public User save(User user) {
		return userAutheticationRepository.save(user);
	}

}
