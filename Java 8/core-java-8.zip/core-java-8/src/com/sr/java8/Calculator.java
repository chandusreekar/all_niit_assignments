package com.sr.java8;
@FunctionalInterface
public interface Calculator {
	public double div(int n1, int n2);

}
