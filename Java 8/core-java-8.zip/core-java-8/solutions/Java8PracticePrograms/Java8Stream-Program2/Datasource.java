package com.streams2;

import java.util.Arrays;
import java.util.List;

public class Datasource {
	
	static List<Customer> customerList = Arrays.asList(new Customer[] {
			new Customer("Mark",30,"Male"),
			new Customer("James",35,"Male"),
			new Customer("Nicky",25,"Female"),
			new Customer("John",31,"Male"),
			new Customer("Manya",30,"Female")
	});
}
