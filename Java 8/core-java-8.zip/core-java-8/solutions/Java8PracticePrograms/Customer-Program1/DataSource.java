package com.java8.assignment1;

import java.util.Arrays;
import java.util.List;

public class DataSource {
	
	static List<Customer> customerList = Arrays.asList(new Customer[] {
			
			 new Customer("Mavis",38,"Male"),
			 new Customer("Rashmi",25,"Female"),
			 new Customer("Vinay",30,"Male"),
			 new Customer("Priya",21,"Female"),
			 new Customer("Mavis",24,"Male")
			
	 });
}
